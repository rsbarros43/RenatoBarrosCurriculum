# Oracle Enterprise Control Center

Versão **v0.1.0** — Estrutura completa, autenticação demonstrativa e dashboard executivo inicial.

## Visão geral

O Oracle Enterprise Control Center é uma plataforma moderna inspirada em consoles corporativos de monitoração Oracle. Esta primeira versão estabelece a arquitetura-base para os módulos futuros de Hosts, Databases, Exadata, OCI, ASM, RAC, Data Guard, Backup, SQL Monitor, AWR, Alert Log e Capacity Planning.

## Recursos da v0.1.0

- Login com token JWT demonstrativo.
- Dashboard executivo responsivo.
- Indicadores de disponibilidade, bancos, hosts, alertas, backups e Data Guard.
- Gráficos de carga, crescimento de armazenamento e distribuição de status.
- Menu lateral preparado para todos os módulos do roadmap.
- Backend Node.js + Express + TypeScript.
- Frontend React + Vite + TypeScript.
- Execução local ou via Docker Compose.
- Script reutilizável para criar a infraestrutura completa de diretórios.

## Credenciais de demonstração

- Usuário: `admin`
- Senha: `Oracle@123`

> As credenciais são apenas para laboratório. Na fase de segurança, serão substituídas por persistência segura, hash de senha e RBAC.

## Execução rápida

### Pré-requisitos

- Node.js 20 ou superior
- npm 10 ou superior

### Instalação

```bash
npm install
npm run install:all
cp .env.example .env
npm run dev
```

Acesse:

- Frontend: `http://localhost:5173`
- Backend: `http://localhost:4000`
- Health check: `http://localhost:4000/api/health`

## Docker

```bash
cp .env.example .env
docker compose up --build
```

Acesse `http://localhost:8080`.

## Script de estrutura

Para criar somente a estrutura de diretórios em outro local:

```bash
chmod +x create-project-structure.sh
./create-project-structure.sh Meu-Projeto
```

Nas próximas versões, a estrutura será preservada e serão entregues somente os arquivos novos ou alterados.

## Roadmap

- v0.1.0 — Estrutura, login e dashboard inicial
- v0.2.0 — Cadastro e monitoração de Hosts
- v0.3.0 — Oracle Database Monitor
- v0.4.0 — ASM
- v0.5.0 — RAC
- v0.6.0 — Data Guard
- v0.7.0 — Backup/RMAN
- v0.8.0 — SQL Monitor
- v0.9.0 — AWR Analyzer
- v1.0.0 — Exadata, OCI e inteligência assistida
