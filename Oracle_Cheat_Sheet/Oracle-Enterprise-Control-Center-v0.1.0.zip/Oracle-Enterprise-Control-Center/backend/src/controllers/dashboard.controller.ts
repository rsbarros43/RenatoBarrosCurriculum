import type { Request, Response } from 'express';
import { buildDashboardPayload } from '../services/dashboard.service.js';

export function getDashboard(_req: Request, res: Response): void {
  res.json(buildDashboardPayload());
}
