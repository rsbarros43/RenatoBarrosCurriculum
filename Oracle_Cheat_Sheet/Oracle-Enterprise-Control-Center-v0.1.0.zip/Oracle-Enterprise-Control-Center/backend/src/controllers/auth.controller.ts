import type { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export function login(req: Request, res: Response): void {
  const { username, password } = req.body as { username?: string; password?: string };

  if (username !== 'admin' || password !== 'Oracle@123') {
    res.status(401).json({ message: 'Usuário ou senha inválidos.' });
    return;
  }

  const user = { username: 'admin', name: 'Administrador Oracle', role: 'DBA_ADMIN' };
  const token = jwt.sign({ username: user.username, role: user.role }, env.jwtSecret, { expiresIn: '8h' });
  res.json({ token, user });
}
