import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env.js';
import { authRouter } from './routes/auth.routes.js';
import { dashboardRouter } from './routes/dashboard.routes.js';

export const app = express();
app.use(helmet());
app.use(cors({ origin: env.corsOrigin }));
app.use(express.json());
app.use(morgan('dev'));
app.get('/api/health', (_req, res) => res.json({ status: 'UP', version: '0.1.0', timestamp: new Date().toISOString() }));
app.use('/api/auth', authRouter);
app.use('/api/dashboard', dashboardRouter);
app.use((_req, res) => res.status(404).json({ message: 'Rota não encontrada.' }));
