export type DashboardPayload = ReturnType<typeof buildDashboardPayload>;

export function buildDashboardPayload() {
  return {
    generatedAt: new Date().toISOString(),
    summary: [
      { id: 'availability', label: 'Disponibilidade', value: '99.97%', detail: 'Últimos 30 dias', status: 'healthy' },
      { id: 'databases', label: 'Bancos', value: 42, detail: '39 online · 3 atenção', status: 'healthy' },
      { id: 'hosts', label: 'Hosts', value: 18, detail: '17 online · 1 manutenção', status: 'warning' },
      { id: 'alerts', label: 'Alertas críticos', value: 3, detail: '12 alertas totais', status: 'critical' },
      { id: 'backups', label: 'Backups OK', value: '96%', detail: 'Últimas 24 horas', status: 'healthy' },
      { id: 'dataguard', label: 'Data Guard', value: 15, detail: '14 sincronizados', status: 'warning' }
    ],
    performance: [
      { time: '08:00', cpu: 31, sessions: 46, iops: 58 },
      { time: '09:00', cpu: 44, sessions: 57, iops: 64 },
      { time: '10:00', cpu: 52, sessions: 68, iops: 73 },
      { time: '11:00', cpu: 47, sessions: 62, iops: 69 },
      { time: '12:00', cpu: 61, sessions: 74, iops: 78 },
      { time: '13:00', cpu: 55, sessions: 70, iops: 72 },
      { time: '14:00', cpu: 66, sessions: 82, iops: 86 }
    ],
    storage: [
      { month: 'Fev', used: 58, forecast: 58 },
      { month: 'Mar', used: 61, forecast: 61 },
      { month: 'Abr', used: 64, forecast: 64 },
      { month: 'Mai', used: 68, forecast: 68 },
      { month: 'Jun', used: 72, forecast: 72 },
      { month: 'Jul', used: 76, forecast: 76 },
      { month: 'Ago', used: null, forecast: 80 },
      { month: 'Set', used: null, forecast: 84 }
    ],
    databaseStatus: [
      { name: 'Online', value: 39 },
      { name: 'Atenção', value: 2 },
      { name: 'Crítico', value: 1 }
    ],
    alerts: [
      { severity: 'critical', source: 'FINPRD', message: 'Tablespace USERS acima de 92%', age: '4 min' },
      { severity: 'critical', source: 'RAC-PROD', message: 'Interconnect com latência elevada', age: '11 min' },
      { severity: 'critical', source: 'DG-SP01', message: 'Apply lag acima de 15 minutos', age: '18 min' },
      { severity: 'warning', source: 'RMAN-ERP', message: 'Backup incremental executado com avisos', age: '34 min' },
      { severity: 'warning', source: 'EXACS01', message: 'Flash cache com utilização elevada', age: '52 min' }
    ],
    environments: [
      { name: 'FINPRD', type: 'Oracle RAC 19c', host: 'rac-fin-01/02', health: 98, status: 'Online' },
      { name: 'ERPPRD', type: 'Oracle 19c', host: 'db-erp-01', health: 94, status: 'Online' },
      { name: 'DWPRD', type: 'Exadata 23ai', host: 'exacs-prod-01', health: 89, status: 'Atenção' },
      { name: 'CRMSTB', type: 'Data Guard', host: 'db-dr-02', health: 82, status: 'Atenção' }
    ]
  };
}
