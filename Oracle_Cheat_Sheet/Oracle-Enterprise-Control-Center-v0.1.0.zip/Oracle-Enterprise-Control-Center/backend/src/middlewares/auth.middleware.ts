import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authorization = req.headers.authorization;
  const token = authorization?.startsWith('Bearer ') ? authorization.slice(7) : undefined;

  if (!token) {
    res.status(401).json({ message: 'Token de acesso não informado.' });
    return;
  }

  try {
    req.user = jwt.verify(token, env.jwtSecret) as { username: string; role: string };
    next();
  } catch {
    res.status(401).json({ message: 'Token inválido ou expirado.' });
  }
}
