export type StatusTone = 'healthy' | 'warning' | 'critical';
export interface User { username: string; name: string; role: string; }
export interface SummaryCard { id: string; label: string; value: string | number; detail: string; status: StatusTone; }
export interface DashboardData {
  generatedAt: string;
  summary: SummaryCard[];
  performance: Array<{ time: string; cpu: number; sessions: number; iops: number }>;
  storage: Array<{ month: string; used: number | null; forecast: number }>;
  databaseStatus: Array<{ name: string; value: number }>;
  alerts: Array<{ severity: string; source: string; message: string; age: string }>;
  environments: Array<{ name: string; type: string; host: string; health: number; status: string }>;
}
