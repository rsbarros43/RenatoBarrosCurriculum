import { Activity, Bell, Boxes, ChartNoAxesCombined, CircleGauge, Cloud, Database, HardDrive, House, Layers3, LogOut, Menu, Network, ScrollText, Search, Server, ShieldCheck } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { Brand } from '../components/common/Brand';
import { useAuth } from '../contexts/AuthContext';

const nav = [
  ['Dashboard', House], ['Hosts', Server], ['Bancos', Database], ['Exadata', Boxes], ['OCI', Cloud], ['ASM', HardDrive], ['RAC', Network], ['Data Guard', ShieldCheck], ['Backup', Layers3], ['SQL Monitor', Activity], ['AWR', ChartNoAxesCombined], ['Alert Log', ScrollText], ['Capacity Planning', CircleGauge]
] as const;

export function AppLayout({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const { user, logout } = useAuth();
  return <div className={`app-shell ${collapsed ? 'collapsed' : ''}`}>
    <aside className="sidebar">
      <div className="sidebar-top"><Brand compact={collapsed}/><button className="icon-button" onClick={() => setCollapsed(v => !v)} aria-label="Alternar menu"><Menu size={20}/></button></div>
      <nav>{nav.map(([label, Icon], index) => <button className={`nav-item ${index === 0 ? 'active' : ''}`} key={label} title={collapsed ? label : undefined}><Icon size={19}/>{!collapsed && <span>{label}</span>}{!collapsed && index > 0 && <small>em breve</small>}</button>)}</nav>
      <button className="nav-item logout" onClick={logout}><LogOut size={19}/>{!collapsed && <span>Sair</span>}</button>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="search-box"><Search size={18}/><input placeholder="Pesquisar bancos, hosts, SQL_ID..." /></div><div className="topbar-actions"><button className="icon-button notification"><Bell size={20}/><i>3</i></button><div className="user-chip"><div className="avatar">RB</div><div><strong>{user?.name}</strong><span>{user?.role}</span></div></div></div></header>
      <section className="content">{children}</section>
    </main>
  </div>;
}
