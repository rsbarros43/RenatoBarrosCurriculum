import { DatabaseZap } from 'lucide-react';
export function Brand({ compact = false }: { compact?: boolean }) {
  return <div className="brand"><div className="brand-mark"><DatabaseZap size={22}/></div>{!compact && <div><strong>Oracle Enterprise</strong><span>Control Center</span></div>}</div>;
}
