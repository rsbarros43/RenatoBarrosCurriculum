import { AlertTriangle, CheckCircle2, Database, HardDriveDownload, Network, Server } from 'lucide-react';
import type { SummaryCard } from '../../types';
const icons = [CheckCircle2, Database, Server, AlertTriangle, HardDriveDownload, Network];
export function SummaryCards({ items }: { items: SummaryCard[] }) { return <div className="summary-grid">{items.map((item, i) => { const Icon=icons[i] ?? Database; return <article className={`summary-card ${item.status}`} key={item.id}><div className="summary-icon"><Icon size={21}/></div><div><span>{item.label}</span><strong>{item.value}</strong><small>{item.detail}</small></div></article>; })}</div>; }
