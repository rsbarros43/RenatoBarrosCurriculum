import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';
import { api } from '../services/api';
import type { User } from '../types';

interface AuthContextValue { user: User | null; login: (u: string, p: string) => Promise<void>; logout: () => void; }
const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const raw = localStorage.getItem('oecc_user');
    return raw ? JSON.parse(raw) as User : null;
  });
  const value = useMemo(() => ({
    user,
    login: async (username: string, password: string) => {
      const result = await api.login(username, password);
      localStorage.setItem('oecc_token', result.token);
      localStorage.setItem('oecc_user', JSON.stringify(result.user));
      setUser(result.user);
    },
    logout: () => { localStorage.removeItem('oecc_token'); localStorage.removeItem('oecc_user'); setUser(null); }
  }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
