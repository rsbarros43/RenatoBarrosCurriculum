import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import { AppLayout } from './layouts/AppLayout';
import { DashboardPage } from './pages/DashboardPage';
import { LoginPage } from './pages/LoginPage';
export default function App(){const {user}=useAuth();return <Routes><Route path="/login" element={user?<Navigate to="/" replace/>:<LoginPage/>}/><Route path="/*" element={user?<AppLayout><DashboardPage/></AppLayout>:<Navigate to="/login" replace/>}/></Routes>}
