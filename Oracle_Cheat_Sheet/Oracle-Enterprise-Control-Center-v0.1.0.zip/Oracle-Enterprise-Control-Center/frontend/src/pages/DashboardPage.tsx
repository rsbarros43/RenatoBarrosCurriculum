import { useEffect, useState } from 'react';
import { AlertOctagon, ArrowUpRight, RefreshCw } from 'lucide-react';
import { PerformanceChart, StatusChart, StorageChart } from '../components/dashboard/Charts';
import { SummaryCards } from '../components/dashboard/SummaryCards';
import { api } from '../services/api';
import type { DashboardData } from '../types';

export function DashboardPage() {
  const [data,setData]=useState<DashboardData|null>(null); const [error,setError]=useState(''); const [loading,setLoading]=useState(true);
  async function load(){setLoading(true);setError('');try{setData(await api.dashboard());}catch(e){setError(e instanceof Error?e.message:'Falha ao carregar');}finally{setLoading(false);}}
  useEffect(()=>{void load();},[]);
  if(loading&&!data)return <div className="state-box"><RefreshCw className="spin"/>Carregando telemetria...</div>;
  if(error&&!data)return <div className="state-box error">{error}<button onClick={load}>Tentar novamente</button></div>;
  if(!data)return null;
  return <><div className="page-heading"><div><span className="eyebrow">Visão operacional</span><h1>Dashboard Executivo</h1><p>Saúde consolidada do ambiente Oracle em tempo quase real.</p></div><button className="secondary-button" onClick={load}><RefreshCw size={17}/>Atualizar</button></div><SummaryCards items={data.summary}/><div className="dashboard-grid"><section className="panel panel-wide"><div className="panel-title"><div><h3>Performance consolidada</h3><span>CPU, sessões e IOPS</span></div><a>Detalhes <ArrowUpRight size={15}/></a></div><PerformanceChart data={data.performance}/></section><section className="panel"><div className="panel-title"><div><h3>Status dos bancos</h3><span>42 instâncias monitoradas</span></div></div><StatusChart data={data.databaseStatus}/></section><section className="panel"><div className="panel-title"><div><h3>Capacity Planning</h3><span>Crescimento e projeção</span></div></div><StorageChart data={data.storage}/></section><section className="panel panel-wide"><div className="panel-title"><div><h3>Ambientes prioritários</h3><span>Saúde dos serviços críticos</span></div></div><div className="table-wrap"><table><thead><tr><th>Ambiente</th><th>Tecnologia</th><th>Host</th><th>Saúde</th><th>Status</th></tr></thead><tbody>{data.environments.map(row=><tr key={row.name}><td><strong>{row.name}</strong></td><td>{row.type}</td><td>{row.host}</td><td><div className="health"><div><i style={{width:`${row.health}%`}}></i></div><span>{row.health}%</span></div></td><td><span className={`badge ${row.status==='Online'?'ok':'warn'}`}>{row.status}</span></td></tr>)}</tbody></table></div></section><section className="panel"><div className="panel-title"><div><h3>Alertas recentes</h3><span>Ordenados por criticidade</span></div><AlertOctagon size={20}/></div><div className="alerts-list">{data.alerts.map((a,i)=><article key={i}><i className={a.severity}></i><div><strong>{a.source}</strong><p>{a.message}</p></div><time>{a.age}</time></article>)}</div></section></div><footer className="dashboard-footer">Última atualização: {new Date(data.generatedAt).toLocaleString('pt-BR')} · v0.1.0</footer></>;
}
