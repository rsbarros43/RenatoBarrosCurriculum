import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, LockKeyhole, ShieldCheck, User } from 'lucide-react';
import { Brand } from '../components/common/Brand';
import { useAuth } from '../contexts/AuthContext';

export function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState('admin'); const [password, setPassword] = useState('Oracle@123');
  const [show, setShow] = useState(false); const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  async function submit(e: FormEvent) { e.preventDefault(); setError(''); setLoading(true); try { await login(username,password); } catch (err) { setError(err instanceof Error ? err.message : 'Falha no login'); } finally { setLoading(false); } }
  return <div className="login-page"><div className="login-visual"><div className="grid-overlay"></div><div className="visual-content"><Brand/><h1>Controle total do seu ecossistema Oracle.</h1><p>Observabilidade, disponibilidade e capacidade em uma experiência única.</p><div className="feature-row"><ShieldCheck/><span>Monitoramento seguro e centralizado</span></div></div></div><div className="login-panel"><form className="login-card" onSubmit={submit}><div className="mobile-brand"><Brand/></div><span className="eyebrow">Acesso administrativo</span><h2>Bem-vindo</h2><p>Entre para acessar o painel operacional.</p><label>Usuário<div className="field"><User size={18}/><input value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username"/></div></label><label>Senha<div className="field"><LockKeyhole size={18}/><input type={show?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/><button type="button" onClick={()=>setShow(v=>!v)}>{show?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></label>{error && <div className="form-error">{error}</div>}<button className="primary-button" disabled={loading}>{loading?'Autenticando...':'Entrar no Control Center'}</button><div className="demo-hint"><strong>Ambiente de demonstração</strong><span>admin / Oracle@123</span></div></form></div></div>;
}
