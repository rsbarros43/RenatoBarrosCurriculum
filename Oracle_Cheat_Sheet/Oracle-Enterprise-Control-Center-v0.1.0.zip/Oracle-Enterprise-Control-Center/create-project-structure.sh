#!/usr/bin/env bash
set -euo pipefail

PROJECT_NAME="${1:-Oracle-Enterprise-Control-Center}"
ROOT="$(pwd)/${PROJECT_NAME}"

DIRS=(
  backend/src/{config,controllers,database,middlewares,models,routes,services,oracle,monitoring,websocket,utils,types}
  backend/tests
  frontend/src/{assets,components,components/charts,components/common,components/dashboard,contexts,hooks,layouts,pages,services,styles,types,utils}
  frontend/public
  docs/{architecture,api,operations}
  scripts/{database,deploy,monitoring}
  docker/{backend,frontend,nginx}
  data
  logs
)

printf '\nCriando estrutura do projeto em: %s\n\n' "$ROOT"
mkdir -p "$ROOT"
cd "$ROOT"
for dir in "${DIRS[@]}"; do
  mkdir -p "$dir"
done

# Mantém diretórios vazios versionáveis.
find backend/tests docs scripts docker data logs -type d -empty -exec touch {}/.gitkeep \;

cat > .gitignore <<'EOF'
node_modules/
dist/
.env
*.log
.DS_Store
coverage/
data/*.db
logs/*
!logs/.gitkeep
EOF

printf 'Estrutura criada com sucesso.\n'
printf 'Próximo passo: copie os arquivos da versão para dentro desta estrutura.\n'
